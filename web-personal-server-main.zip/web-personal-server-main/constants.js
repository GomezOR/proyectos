const DB_USER = "admin";
const DB_PASSWORD = "admin123456";
const DB_HOST = "web-personal.1hnuc3c.mongodb.net";

const API_VERSION = "v1";
const IP_SERVER = "localhost";

const JWT_SECRET_KEY = "gR7cH9Svfj8JLe4c186Ghs48hheb3902nh5DsA";

module.exports = {
  DB_USER,
  DB_PASSWORD,
  DB_HOST,
  API_VERSION,
  IP_SERVER,
  JWT_SECRET_KEY,
};
